set -vex
#brew install pyenv
#which pyenv
